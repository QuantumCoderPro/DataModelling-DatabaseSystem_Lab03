USE classicmodels;

-- Q1_721424060_S92064060

DELIMITER //

CREATE PROCEDURE DisplayCustomerOrders(IN customerNumber INT)
BEGIN
    SELECT * FROM orders WHERE customerNumber = customerNumber;
END //

DELIMITER ;

CALL DisplayCustomerOrders(129);

-- Q2_721424060_S92064060

DELIMITER //

CREATE PROCEDURE GetCustomerOrderAmount(
    IN customerNumber INT,
    OUT orderAmount DECIMAL(10, 2)
)
BEGIN
    SELECT SUM(od.quantityOrdered * od.priceEach) INTO orderAmount
    FROM orders o
    JOIN orderdetails od ON o.orderNumber = od.orderNumber
    WHERE o.customerNumber = customerNumber;
END //

DELIMITER ;

CALL GetCustomerOrderAmount(129, @Amount);
SELECT 'Order Amount' AS 'Column Header', @Amount AS 'Amount';

-- Q3_721424060_S92064060

DELIMITER //

CREATE PROCEDURE GetMaxCreditLimitByCustomer(
    INOUT customerNumber INT
)
BEGIN
    SELECT MAX(creditLimit) INTO customerNumber
    FROM customers
    WHERE customerNumber = customerNumber;
END //

DELIMITER ;

SET @customerNumber = 129;
CALL GetMaxCreditLimitByCustomer(@customerNumber);
SELECT 'Maximum Credit Limit' AS 'Column Header', @customerNumber AS 'Credit Limit';

-- Q4_721424060_S92064060

DELIMITER //

CREATE FUNCTION CalculateTotalPaymentsByCustomer (customerNumber INT) RETURNS DECIMAL(10, 2)
DETERMINISTIC
BEGIN
    DECLARE totalAmount DECIMAL(10, 2);
    
    SELECT SUM(amount) INTO totalAmount
    FROM payments
    WHERE customerNumber = customerNumber;
    
    RETURN totalAmount;
END //

DELIMITER ;

-- Q5_721424060_S92064060

SELECT 'Total Amount Paid' AS 'Column Header', CalculateTotalPaymentsByCustomer(124) AS 'Amount';

-- Q6_721424060_S92064060

SELECT customerNumber, CalculateTotalPaymentsByCustomer(customerNumber) AS 'Total Payment'
FROM customers;

-- Q7_721424060_S92064060

DELIMITER //
CREATE FUNCTION GetNumberOfReportingEmployees (employeeNumber INT) RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE ReportingEmployeesCount INT;

    SELECT COUNT(*) INTO ReportingEmployeesCount
    FROM employees
    WHERE reportsTo = employeeNumber;

    RETURN ReportingEmployeesCount;
END //
DELIMITER ;

SELECT 'Reporting Employees Count' AS 'Column Header', GetNumberOfReportingEmployees(1002) AS 'Reporting Employees';

